__version__ = '0.0.14'
__author__ = 'Wiredcraft'

class PipelinesError(RuntimeError):
    pass
