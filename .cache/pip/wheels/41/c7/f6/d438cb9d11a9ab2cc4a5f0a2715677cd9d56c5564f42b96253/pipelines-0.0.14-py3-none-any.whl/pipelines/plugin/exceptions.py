class PluginError(RuntimeError):
    pass
