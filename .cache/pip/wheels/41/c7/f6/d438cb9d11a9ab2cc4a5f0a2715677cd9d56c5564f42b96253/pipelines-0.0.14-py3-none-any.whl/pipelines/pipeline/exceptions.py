class PipelineError(RuntimeError):
    pass

